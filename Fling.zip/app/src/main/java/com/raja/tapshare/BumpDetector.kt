package com.raja.tapshare

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Detects the "top-to-top touch": a sharp spike of acceleration that is mostly along the
 * phone's long (Y) axis. Both phones feel the same impact at the same moment.
 */
class BumpDetector(
    context: Context,
    private val onBump: (Float) -> Unit,
    private val onLevel: (Float, Float) -> Unit
) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linear: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    @Volatile
    var sensitivity: Int = 5

    @Volatile
    var streamLevel: Boolean = false

    private var running = false
    private var lastBump = 0L
    private var lastLevel = 0L
    private val grav = FloatArray(3)
    private var gravInit = false

    val available: Boolean get() = linear != null || accel != null

    fun threshold(): Float = max(6f, 20.5f - 1.5f * sensitivity)

    fun start() {
        if (running) return
        val s = linear ?: accel ?: return
        gravInit = false
        running = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!running) return
        sm.unregisterListener(this)
        running = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        var x = e.values[0]
        var y = e.values[1]
        var z = e.values[2]
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            // remove gravity with a low-pass filter
            if (!gravInit) {
                grav[0] = x; grav[1] = y; grav[2] = z
                gravInit = true
            }
            val a = 0.85f
            grav[0] = a * grav[0] + (1 - a) * x
            grav[1] = a * grav[1] + (1 - a) * y
            grav[2] = a * grav[2] + (1 - a) * z
            x -= grav[0]; y -= grav[1]; z -= grav[2]
        }
        val mag = sqrt(x * x + y * y + z * z)
        val yShare = if (mag > 0.01f) abs(y) / mag else 0f
        val now = SystemClock.elapsedRealtime()
        val thr = threshold()
        if (streamLevel && now - lastLevel > 90) {
            lastLevel = now
            onLevel(mag, thr)
        }
        if (mag >= thr && yShare >= 0.5f && now - lastBump > 1500) {
            lastBump = now
            onBump(mag)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

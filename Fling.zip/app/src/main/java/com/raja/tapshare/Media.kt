package com.raja.tapshare

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Size
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale

/** One thing the user can send. */
class OutFile(
    val key: String,
    val name: String,
    var size: Long,
    val mime: String,
    val uri: Uri?,
    val path: String?,
    val kind: String,
    val splits: List<String> = emptyList()
)

object Media {

    fun mimeFor(name: String, fallback: String?): String {
        if (!fallback.isNullOrBlank() && fallback != "application/octet-stream") return fallback
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val m = if (ext.isNotEmpty()) MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) else null
        return m ?: "application/octet-stream"
    }

    fun safeName(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim()
        return if (s.isEmpty()) "file" else s.take(120)
    }

    /** Build an OutFile from any content/file Uri (picker, share intent, MediaStore). */
    fun fromUri(cr: ContentResolver, uri: Uri, kindHint: String = "file"): OutFile? {
        var name: String? = null
        var size = -1L
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {
        }
        if (name == null) name = uri.lastPathSegment ?: "file"
        if (size < 0) {
            try {
                cr.openFileDescriptor(uri, "r")?.use { size = it.statSize }
            } catch (_: Exception) {
            }
        }
        if (size < 0) return null
        val nm = safeName(name!!)
        return OutFile("u:$uri", nm, size, mimeFor(nm, cr.getType(uri)), uri, null, kindHint)
    }

    // ---------- gallery listing ----------

    fun listMedia(ctx: Context, kind: String, catalog: MutableMap<String, OutFile>): String {
        val cr = ctx.contentResolver
        val base: Uri
        val sel: String?
        when (kind) {
            "photos" -> base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            "videos" -> base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        sel = if (kind == "music") MediaStore.Audio.Media.IS_MUSIC + " != 0" else null
        val out = JSONArray()
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE
        )
        try {
            cr.query(base, proj, sel, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                var n = 0
                while (c.moveToNext() && n < 500) {
                    val id = c.getLong(iId)
                    val uri = ContentUris.withAppendedId(base, id)
                    val name = safeName(c.getString(iName) ?: "file_$id")
                    val size = c.getLong(iSize)
                    if (size <= 0) continue
                    val key = "m:$kind:$id"
                    val f = OutFile(key, name, size, mimeFor(name, c.getString(iMime)), uri, null, kind)
                    catalog[key] = f
                    out.put(itemJson(f, uri.toString()))
                    n++
                }
            }
        } catch (_: Exception) {
        }
        return out.toString()
    }

    fun listApps(ctx: Context, catalog: MutableMap<String, OutFile>): String {
        val pm = ctx.packageManager
        val out = JSONArray()
        val list = try {
            pm.getInstalledApplications(0)
        } catch (_: Exception) {
            emptyList<ApplicationInfo>()
        }
        val rows = ArrayList<OutFile>()
        for (ai in list) {
            if (ai.packageName == ctx.packageName) continue
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val upd = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (sys && !upd) continue
            val src = ai.sourceDir ?: continue
            val f = File(src)
            if (!f.exists()) continue
            val label = try {
                pm.getApplicationLabel(ai).toString()
            } catch (_: Exception) {
                ai.packageName
            }
            val splits = ai.splitSourceDirs?.toList() ?: emptyList()
            var size = f.length()
            for (s in splits) size += File(s).length()
            val fname = safeName(label) + if (splits.isEmpty()) ".apk" else ".apks"
            val mime = if (splits.isEmpty()) "application/vnd.android.package-archive" else "application/octet-stream"
            rows.add(OutFile("a:" + ai.packageName, fname, size, mime, null, src, "apps", splits))
        }
        rows.sortBy { it.name.lowercase(Locale.ROOT) }
        for (r in rows) {
            catalog[r.key] = r
            val pkg = r.key.substring(2)
            val o = itemJson(r, "")
            o.put("pkg", pkg)
            o.put("split", r.splits.isNotEmpty())
            out.put(o)
        }
        return out.toString()
    }

    private fun itemJson(f: OutFile, u: String): JSONObject {
        val o = JSONObject()
        o.put("k", f.key)
        o.put("n", f.name)
        o.put("s", f.size)
        o.put("m", f.mime)
        o.put("u", u)
        o.put("kind", f.kind)
        return o
    }

    fun selectionJson(f: OutFile): JSONObject {
        val o = JSONObject()
        o.put("k", f.key)
        o.put("n", f.name)
        o.put("s", f.size)
        o.put("m", f.mime)
        o.put("kind", f.kind)
        return o
    }

    // ---------- thumbnails (served to the WebView) ----------

    fun thumbBytes(ctx: Context, uriStr: String): ByteArray? {
        if (!uriStr.startsWith("content://media/")) return null
        return try {
            val bmp = ctx.contentResolver.loadThumbnail(Uri.parse(uriStr), Size(220, 220), null)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
            bos.toByteArray()
        } catch (_: Exception) {
            null
        }
    }

    fun appIconBytes(ctx: Context, pkg: String): ByteArray? {
        return try {
            val d: Drawable = ctx.packageManager.getApplicationIcon(pkg)
            val sz = 120
            val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            d.setBounds(0, 0, sz, sz)
            d.draw(cv)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            bos.toByteArray()
        } catch (_: Exception) {
            null
        }
    }
}

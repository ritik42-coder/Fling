package com.raja.tapshare

import android.app.Activity
import android.app.DownloadManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity(), ShareEngine.Listener {

    companion object {
        const val REQ_NEARBY = 11
        const val REQ_MEDIA = 12
        const val REQ_PICK = 13
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var bump: BumpDetector
    private val ui = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var insetTop = 0
    private var insetBottom = 0
    private var pendingMediaKind: String? = null
    private var vib: Vibrator? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        ShareEngine.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setupEdgeToEdge()

        web = WebView(this)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.setBackgroundColor(Color.parseColor("#070A18"))
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == "tapshare.local") {
                    if (u.path == "/thumb") {
                        val raw = u.getQueryParameter("u")
                        val bytes = if (raw != null) Media.thumbBytes(applicationContext, raw) else null
                        return resp("image/jpeg", bytes)
                    }
                    if (u.path == "/appicon") {
                        val pkg = u.getQueryParameter("p")
                        val bytes = if (pkg != null) Media.appIconBytes(applicationContext, pkg) else null
                        return resp("image/png", bytes)
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.scheme != "file"
            }
        }

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#070A18"))
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnApplyWindowInsetsListener { _, insets ->
            readInsets(insets)
            pushInsets()
            insets
        }
        setContentView(root)

        bump = BumpDetector(
            this,
            { _ -> ShareEngine.onLocalBump() },
            { mag, thr -> js("window.TS&&TS.onLevel(" + mag + "," + thr + ")") }
        )
        bump.sensitivity = Store.sensitivity
        @Suppress("DEPRECATION")
        vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        web.loadUrl("file:///android_asset/index.html")
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        ShareEngine.listener = this
        bump.start()
        ShareEngine.setForeground(true)
        if (pageReady) {
            pushSys()
            js("window.TS&&TS.onState(" + lit(ShareEngine.lastJson) + ")")
        }
    }

    override fun onPause() {
        super.onPause()
        bump.stop()
        ShareEngine.setForeground(false)
    }

    override fun onDestroy() {
        ShareEngine.listener = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!pageReady) {
            moveTaskToBack(true)
            return
        }
        web.evaluateJavascript("(window.TS?TS.back():false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    // ------------------------------------------------------------------ window / insets

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    @Suppress("DEPRECATION")
    private fun readInsets(i: WindowInsets) {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = i.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            insetTop = b.top
            insetBottom = b.bottom
        } else {
            insetTop = i.systemWindowInsetTop
            insetBottom = i.systemWindowInsetBottom
        }
    }

    private fun pushInsets() {
        val d = resources.displayMetrics.density
        js("window.TS&&TS.insets(" + (insetTop / d) + "," + (insetBottom / d) + ")")
    }

    @Suppress("DEPRECATION")
    private fun applyBars(light: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(if (light) m else 0, m)
        } else {
            var f = window.decorView.systemUiVisibility
            val m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            f = if (light) (f or m) else (f and m.inv())
            window.decorView.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ JS plumbing

    private fun js(code: String) {
        if (!pageReady) return
        web.evaluateJavascript(code, null)
    }

    private fun lit(s: String): String = s.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

    private fun resp(mime: String, bytes: ByteArray?): WebResourceResponse {
        if (bytes == null) {
            return WebResourceResponse(mime, null, 404, "Not Found", HashMap<String, String>(), ByteArrayInputStream(ByteArray(0)))
        }
        val h = HashMap<String, String>()
        h["Cache-Control"] = "max-age=3600"
        h["Access-Control-Allow-Origin"] = "*"
        return WebResourceResponse(mime, null, 200, "OK", h, ByteArrayInputStream(bytes))
    }

    override fun onState(json: String) {
        js("window.TS&&TS.onState(" + lit(json) + ")")
    }

    override fun onEvent(json: String) {
        try {
            when (JSONObject(json).optString("t")) {
                "bump" -> haptic("bump")
                "done" -> haptic("done")
                "offer" -> haptic("tick")
                "link" -> haptic("tick")
                "error" -> haptic("error")
            }
        } catch (_: Exception) {
        }
        js("window.TS&&TS.onEvent(" + lit(json) + ")")
    }

    private fun haptic(kind: String) {
        if (!Store.haptics) return
        val v = vib ?: return
        val pattern = when (kind) {
            "bump" -> longArrayOf(0, 22, 45, 34)
            "done" -> longArrayOf(0, 28, 70, 28, 70, 60)
            "error" -> longArrayOf(0, 60, 60, 60)
            else -> longArrayOf(0, 14)
        }
        try {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (_: Exception) {
        }
    }

    private fun settingsJson(): String {
        val o = JSONObject()
        o.put("name", Store.deviceName)
        o.put("sens", Store.sensitivity)
        o.put("haptics", Store.haptics)
        o.put("theme", Store.theme)
        o.put("sensor", bump.available)
        o.put("ver", "1.2.0")
        o.put("saveDir", "Downloads/Fling")
        return o.toString()
    }

    private fun btOn(): Boolean {
        return try {
            val bm = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            bm?.adapter?.isEnabled == true
        } catch (_: Exception) {
            true
        }
    }

    private fun wifiOn(): Boolean {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.isWifiEnabled
        } catch (_: Exception) {
            true
        }
    }

    private fun locOk(): Boolean {
        if (Build.VERSION.SDK_INT >= 31) return true
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.isLocationEnabled
        } catch (_: Exception) {
            true
        }
    }

    private fun sysJson(): String {
        val o = JSONObject()
        o.put("perm", Perms.has(this, Perms.nearby()))
        o.put("bt", btOn())
        o.put("wifi", wifiOn())
        o.put("loc", locOk())
        o.put("sensor", bump.available)
        return o.toString()
    }

    private fun pushSys() {
        js("window.TS&&TS.onSys(" + lit(sysJson()) + ")")
    }

    private fun pushSettings() {
        js("window.TS&&TS.onSettings(" + lit(settingsJson()) + ")")
    }

    // ------------------------------------------------------------------ picking / sharing in

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = ArrayList<Uri>()
        @Suppress("DEPRECATION")
        if (i.action == Intent.ACTION_SEND) {
            val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) uris.add(u)
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            val l = i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            if (l != null) uris.addAll(l)
        } else {
            return
        }
        val cd = i.clipData
        if (uris.isEmpty() && cd != null) {
            for (k in 0 until cd.itemCount) {
                val u = cd.getItemAt(k).uri
                if (u != null) uris.add(u)
            }
        }
        i.action = null
        if (uris.isNotEmpty()) addUris(uris)
    }

    private fun addUris(uris: List<Uri>) {
        val cr = contentResolver
        Thread {
            val list = ArrayList<OutFile>()
            for (u in uris) {
                try {
                    cr.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                val f = Media.fromUri(cr, u)
                if (f != null) list.add(f)
            }
            ui.post {
                if (list.isNotEmpty()) {
                    ShareEngine.addFiles(list)
                    ShareEngine.toast(if (list.size == 1) "Added 1 file" else "Added " + list.size + " files")
                } else {
                    ShareEngine.toast("Couldn't read that file")
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) {
                    val u = cd.getItemAt(k).uri
                    if (u != null) uris.add(u)
                }
            } else if (data.data != null) {
                uris.add(data.data!!)
            }
            if (uris.isNotEmpty()) addUris(uris)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NEARBY) {
            pushSys()
            ShareEngine.setForeground(true)
            if (!Perms.has(this, Perms.nearby())) {
                ShareEngine.toast("Nearby access is needed to find the other phone")
            }
        } else if (requestCode == REQ_MEDIA) {
            val kind = pendingMediaKind
            pendingMediaKind = null
            if (Perms.has(this, Perms.media()) && kind != null) {
                loadList(kind)
            } else {
                js("window.TS&&TS.onList('" + (kind ?: "photos") + "', null)")
                ShareEngine.toast("Allow access to browse your library, or use Files")
            }
        }
    }

    private fun loadList(kind: String) {
        val appCtx = applicationContext
        Thread {
            val tmp = LinkedHashMap<String, OutFile>()
            val json = if (kind == "apps") Media.listApps(appCtx, tmp) else Media.listMedia(appCtx, kind, tmp)
            ui.post {
                ShareEngine.catalog.putAll(tmp)
                js("window.TS&&TS.onList('" + kind + "'," + lit(json) + ")")
            }
        }.start()
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            ShareEngine.toast("Couldn't open settings")
        }
    }

    // ------------------------------------------------------------------ JS bridge

    inner class Bridge {

        @JavascriptInterface
        fun ready() {
            ui.post {
                pageReady = true
                pushInsets()
                pushSettings()
                pushSys()
                js("window.TS&&TS.onState(" + lit(ShareEngine.lastJson) + ")")
                // ask for Nearby access straight away instead of waiting for a tap
                if (!Perms.has(this@MainActivity, Perms.nearby())) requestPerms()
            }
        }

        @JavascriptInterface
        fun getState(): String = ShareEngine.lastJson

        @JavascriptInterface
        fun requestPerms() {
            ui.post {
                val all = ArrayList<String>()
                for (p in Perms.nearby()) all.add(p)
                for (p in Perms.notifications()) all.add(p)
                val need = ArrayList<String>()
                for (p in all) if (checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) need.add(p)
                if (need.isEmpty()) {
                    pushSys()
                    ShareEngine.setForeground(true)
                } else {
                    requestPermissions(need.toTypedArray(), REQ_NEARBY)
                }
            }
        }

        @JavascriptInterface
        fun pickFiles() {
            ui.post {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(i, REQ_PICK)
                } catch (_: Exception) {
                    ShareEngine.toast("No file picker available")
                }
            }
        }

        @JavascriptInterface
        fun listMedia(kind: String) {
            ui.post {
                if (kind == "apps") {
                    loadList("apps")
                } else if (Perms.has(this@MainActivity, Perms.media())) {
                    loadList(kind)
                } else {
                    pendingMediaKind = kind
                    requestPermissions(Perms.media(), REQ_MEDIA)
                }
            }
        }

        @JavascriptInterface
        fun toggle(key: String) {
            ui.post { ShareEngine.toggle(key) }
        }

        @JavascriptInterface
        fun removeFile(key: String) {
            ui.post { ShareEngine.removeFile(key) }
        }

        @JavascriptInterface
        fun clearSelection() {
            ui.post { ShareEngine.clearSelection() }
        }

        @JavascriptInterface
        fun sendTo(endpointId: String) {
            ui.post { ShareEngine.sendTo(endpointId) }
        }

        @JavascriptInterface
        fun respond(accept: Boolean) {
            ui.post { ShareEngine.respond(accept) }
        }

        @JavascriptInterface
        fun cancel() {
            ui.post { ShareEngine.cancel() }
        }

        @JavascriptInterface
        fun dismiss() {
            ui.post { ShareEngine.dismiss() }
        }

        @JavascriptInterface
        fun openFile(uri: String, mime: String) {
            ui.post {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(Uri.parse(uri), mime)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (_: Exception) {
                    ShareEngine.toast("No app can open this file")
                }
            }
        }

        @JavascriptInterface
        fun openDownloads() {
            ui.post { openSettings(DownloadManager.ACTION_VIEW_DOWNLOADS) }
        }

        @JavascriptInterface
        fun openBluetooth() {
            ui.post { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
        }

        @JavascriptInterface
        fun openWifi() {
            ui.post { openSettings(Settings.ACTION_WIFI_SETTINGS) }
        }

        @JavascriptInterface
        fun openLocation() {
            ui.post { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }
        }

        @JavascriptInterface
        fun openAppSettings() {
            ui.post {
                try {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                    startActivity(i)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getHistory(): String = Store.history().toString()

        @JavascriptInterface
        fun clearHistory() {
            Store.clearHistory()
        }

        @JavascriptInterface
        fun setSetting(key: String, value: String) {
            ui.post {
                when (key) {
                    "name" -> {
                        if (value.isNotBlank()) {
                            Store.deviceName = value
                            ShareEngine.refreshName()
                        }
                    }
                    "sens" -> {
                        val n = value.toIntOrNull() ?: 5
                        Store.sensitivity = n
                        bump.sensitivity = Store.sensitivity
                    }
                    "haptics" -> Store.haptics = value == "1"
                    "theme" -> Store.theme = value
                }
                pushSettings()
            }
        }

        @JavascriptInterface
        fun setBars(light: Boolean) {
            ui.post { applyBars(light) }
        }

        @JavascriptInterface
        fun levelStream(on: Boolean) {
            bump.streamLevel = on
        }

        @JavascriptInterface
        fun haptic(kind: String) {
            ui.post { this@MainActivity.haptic(kind) }
        }

        @JavascriptInterface
        fun testBump() {
            ui.post { ShareEngine.onLocalBump() }
        }
    }
}

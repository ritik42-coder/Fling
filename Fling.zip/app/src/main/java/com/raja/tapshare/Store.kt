package com.raja.tapshare

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Tiny settings + history store (SharedPreferences). */
object Store {
    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null

    fun init(c: Context) {
        if (prefs == null) {
            appContext = c.applicationContext
            prefs = c.applicationContext.getSharedPreferences("tapshare", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = prefs!!

    val deviceId: String
        get() {
            var id = p().getString("id", null)
            if (id == null) {
                id = UUID.randomUUID().toString().replace("-", "").substring(0, 6)
                p().edit().putString("id", id).apply()
            }
            return id
        }

    var deviceName: String
        get() {
            val saved = p().getString("name", null)
            if (!saved.isNullOrBlank()) return saved
            var n: String? = null
            try {
                n = Settings.Global.getString(appContext!!.contentResolver, "device_name")
            } catch (_: Exception) {
            }
            if (n.isNullOrBlank()) n = Build.MODEL
            return n!!.trim().take(28)
        }
        set(v) {
            p().edit().putString("name", v.trim().take(28)).apply()
        }

    var sensitivity: Int
        get() = p().getInt("sens", 5)
        set(v) {
            p().edit().putInt("sens", v.coerceIn(1, 10)).apply()
        }

    var haptics: Boolean
        get() = p().getBoolean("haptics", true)
        set(v) {
            p().edit().putBoolean("haptics", v).apply()
        }

    var theme: String
        get() = p().getString("theme", "dark") ?: "dark"
        set(v) {
            p().edit().putString("theme", v).apply()
        }

    // ---- history ----
    @Synchronized
    fun history(): JSONArray {
        return try {
            JSONArray(p().getString("history", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
    }

    @Synchronized
    fun addHistory(name: String, size: Long, mime: String, dir: String, peer: String, uri: String?) {
        val old = history()
        val out = JSONArray()
        val o = JSONObject()
        o.put("n", name)
        o.put("s", size)
        o.put("m", mime)
        o.put("d", dir)
        o.put("p", peer)
        o.put("t", System.currentTimeMillis())
        if (uri != null) o.put("u", uri)
        out.put(o)
        var i = 0
        while (i < old.length() && out.length() < 150) {
            out.put(old.get(i))
            i++
        }
        p().edit().putString("history", out.toString()).apply()
    }

    @Synchronized
    fun clearHistory() {
        p().edit().putString("history", "[]").apply()
    }
}

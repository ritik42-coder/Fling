package com.raja.tapshare

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.os.SystemClock
import android.provider.MediaStore
import android.system.Os
import android.system.OsConstants
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs

object Perms {
    fun nearby(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT <= 32) l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        return l.toTypedArray()
    }

    fun notifications(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()

    fun media(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun has(ctx: Context, perms: Array<String>): Boolean {
        for (p in perms) {
            if (ctx.checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) return false
        }
        return true
    }
}

/**
 * The whole offline transfer brain: discovery, touch matching, connection, offer/accept
 * handshake, sequential file sending, receiving into Downloads/TapShare.
 * Everything here runs on the main thread (Nearby callbacks + posted bridge calls).
 */
object ShareEngine {
    const val SERVICE_ID = "com.raja.tapshare.v1"
    private const val BUMP_WINDOW = 6000L

    interface Listener {
        fun onState(json: String)
        fun onEvent(json: String)
    }

    private class Peer(val endpointId: String, val devId: String, val name: String, val flag: Char, val foundAt: Long)

    private class FileRow(val name: String, val size: Long, val mime: String) {
        var done = 0L
        var finished = false
        var saving = false
        var uri: String? = null
        var pid = 0L
    }

    private class Session(
        val endpointId: String,
        val peerName: String,
        val peerId: String,
        val initiator: Boolean,
        val viaBump: Boolean
    )

    private lateinit var app: Context
    private lateinit var client: ConnectionsClient
    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private var inited = false

    @Volatile
    var listener: Listener? = null

    @Volatile
    var lastJson: String = "{}"

    val catalog = LinkedHashMap<String, OutFile>()
    val selection = LinkedHashMap<String, OutFile>()
    private val peers = LinkedHashMap<String, Peer>()
    private val cancelledEps = HashMap<String, Long>()

    private var session: Session? = null
    private var pendingEp: String? = null
    private var connected = false
    private var phase = "idle"   // idle | link | offer | xfer | done | error
    private var dir = "out"
    private var role = "none"   // none | sender | receiver - only one phone sends per session
    private val trail = ArrayDeque<String>()
    private var rows = ArrayList<FileRow>()
    private var outList = ArrayList<OutFile>()
    private var total = 0L
    private var msg = ""
    private var peerName = ""
    private var startedAt = 0L
    private var endedAt = 0L
    private var speed = 0L
    private var lastSpeedAt = 0L
    private var lastSpeedBytes = 0L
    private var myBumpAt = 0L
    private var foreground = false
    private var readyOn = false
    private var readyErr = ""
    private var offerSent = false
    private var autoAccept = false
    private val pidIndex = HashMap<Long, Int>()
    private val incoming = HashMap<Long, Payload>()
    private val pendingSuccess = HashSet<Long>()
    private val recvBytes = HashMap<Long, Long>()
    private var notifAt = 0L
    private var lastPush = 0L
    private var pushScheduled = false
    private var step = ""
    private var awaitAck = false
    private var bumpReq = false
    private var retries = 0
    private var ackToken = 0
    private val streamPids = HashSet<Long>()

    @Volatile
    private var lastProgressAt = 0L

    private fun isCancelled(ep: String): Boolean {
        val t = cancelledEps[ep] ?: return false
        if (now() - t > 8000L) {
            cancelledEps.remove(ep)
            return false
        }
        return true
    }

    fun init(context: Context) {
        if (inited) return
        app = context.applicationContext
        client = Nearby.getConnectionsClient(app)
        inited = true
        try {
            File(app.cacheDir, "apks").deleteRecursively()
        } catch (_: Exception) {
        }
        push(true)
    }

    // ------------------------------------------------------------------ state out

    private fun now(): Long = SystemClock.elapsedRealtime()

    private fun doneBytes(): Long {
        var d = 0L
        for (r in rows) d += if (r.finished) r.size else r.done
        return d
    }

    private fun snapshot(): JSONObject {
        val o = JSONObject()
        o.put("phase", phase)
        o.put("dir", dir)
        o.put("peer", peerName)
        o.put("msg", msg)
        if (phase == "link" && step.isNotEmpty()) o.put("step", step)
        if (awaitAck) o.put("wait", "Waiting for " + peerName + " to finish saving\u2026")
        if (phase == "error" && trail.isNotEmpty()) o.put("trail", trail.joinToString("  "))
        o.put("ready", readyOn)
        o.put("readyErr", readyErr)
        o.put("me", Store.deviceName)
        o.put("autoAccept", autoAccept)
        val sel = JSONArray()
        var selSize = 0L
        for (f in selection.values) {
            sel.put(Media.selectionJson(f))
            selSize += f.size
        }
        o.put("selection", sel)
        o.put("selSize", selSize)
        // one bubble per phone (newest advertisement wins)
        val byDev = LinkedHashMap<String, Peer>()
        for (p in peers.values) {
            val old = byDev[p.devId]
            if (old == null || p.foundAt >= old.foundAt) byDev[p.devId] = p
        }
        val ps = JSONArray()
        for (p in byDev.values) {
            val po = JSONObject()
            po.put("id", p.endpointId)
            po.put("d", p.devId)
            po.put("n", p.name)
            po.put("b", p.flag != '0')
            ps.put(po)
        }
        o.put("peers", ps)
        if (phase != "idle") {
            val rs = JSONArray()
            for (r in rows) {
                val ro = JSONObject()
                ro.put("n", r.name)
                ro.put("s", r.size)
                ro.put("m", r.mime)
                val p = if (r.finished) 1.0 else if (r.size > 0) r.done.toDouble() / r.size.toDouble() else 0.0
                ro.put("p", p)
                ro.put("f", r.finished)
                ro.put("w", r.saving)
                if (r.uri != null) ro.put("u", r.uri)
                rs.put(ro)
            }
            o.put("rows", rs)
            o.put("total", total)
            o.put("done", doneBytes())
            o.put("speed", speed)
            val remain = (total - doneBytes()).coerceAtLeast(0L)
            o.put("eta", if (speed > 0) remain * 1000L / speed else 0L)
            val end = if (endedAt > 0) endedAt else now()
            o.put("elapsed", if (startedAt > 0) end - startedAt else 0L)
        }
        return o
    }

    private fun push(force: Boolean = false) {
        val t = now()
        if (!force && t - lastPush < 80) {
            if (!pushScheduled) {
                pushScheduled = true
                main.postDelayed({
                    pushScheduled = false
                    push(true)
                }, 90)
            }
            return
        }
        lastPush = t
        val j = snapshot().toString()
        lastJson = j
        listener?.onState(j)
        if (phase == "xfer" && t - notifAt > 1000) {
            notifAt = t
            val pct = if (total > 0) (doneBytes() * 100L / total).toInt() else 0
            TransferService.start(app, (if (dir == "out") "Sending " else "Receiving ") + pct + "%")
        }
    }

    private fun emit(type: String, i: Int = -1, text: String = "") {
        val o = JSONObject()
        o.put("t", type)
        o.put("i", i)
        if (text.isNotEmpty()) o.put("m", text)
        listener?.onEvent(o.toString())
    }

    fun toast(text: String) = emit("toast", -1, text)

    // ------------------------------------------------------------------ selection

    fun toggle(key: String) {
        val f = catalog[key] ?: return
        if (selection.containsKey(key)) selection.remove(key) else selection[key] = f
        push(true)
    }

    fun addFiles(list: List<OutFile>) {
        for (f in list) selection[f.key] = f
        push(true)
    }

    fun removeFile(key: String) {
        selection.remove(key)
        push(true)
    }

    fun clearSelection() {
        selection.clear()
        push(true)
    }

    // ------------------------------------------------------------------ ready mode (advertise + discover)

    fun setForeground(fg: Boolean) {
        foreground = fg
        if (!inited) return
        if (fg) startReady() else if (session == null && pendingEp == null) stopReady()
    }

    fun refreshName() {
        if (readyOn) restartAdvertising()
        push(true)
    }

    private fun clean(n: String): String = n.replace('|', ' ').trim().take(28)

    private fun flagChar(): Char {
        if (myBumpAt > 0 && now() - myBumpAt < BUMP_WINDOW) return if (selection.isNotEmpty()) '2' else '1'
        return '0'
    }

    private fun advName(): String = Store.deviceId + "|" + flagChar() + "|" + clean(Store.deviceName)

    private fun startReady() {
        if (!inited || readyOn) return
        if (!Perms.has(app, Perms.nearby())) {
            readyErr = "perm"
            push(true)
            return
        }
        readyOn = true
        readyErr = ""
        startAdvertising()
        startDiscovery()
        push(true)
    }

    private fun stopReady() {
        if (!readyOn) return
        readyOn = false
        try {
            client.stopAdvertising()
        } catch (_: Exception) {
        }
        try {
            client.stopDiscovery()
        } catch (_: Exception) {
        }
        peers.clear()
        push(true)
    }

    private fun restartReady() {
        stopReady()
        main.postDelayed({ if (foreground && session == null) startReady() }, 450)
    }

    private fun startAdvertising() {
        val opts = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startAdvertising(advName(), SERVICE_ID, lifecycle, opts)
            .addOnFailureListener { e -> onStartFail(e) }
    }

    private fun startDiscovery() {
        val opts = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startDiscovery(SERVICE_ID, discoveryCb, opts)
            .addOnFailureListener { e -> onStartFail(e) }
    }

    private fun restartAdvertising() {
        if (!readyOn || session != null || pendingEp != null) return
        try {
            client.stopAdvertising()
        } catch (_: Exception) {
        }
        main.postDelayed({ if (readyOn && session == null && pendingEp == null) startAdvertising() }, 150)
    }

    private fun onStartFail(e: Exception) {
        val code = (e as? ApiException)?.statusCode ?: -1
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING ||
            code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING
        ) return
        readyErr = "start:$code"
        push(true)
    }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val parts = info.endpointName.split("|", limit = 3)
            if (parts.size < 3 || parts[1].isEmpty()) return
            if (parts[0] == Store.deviceId) return
            val p = Peer(endpointId, parts[0], parts[2], parts[1][0], now())
            peers[endpointId] = p
            push(true)
            if (p.flag != '0' || myBumpAt > 0L) tryMatch()
        }

        override fun onEndpointLost(endpointId: String) {
            peers.remove(endpointId)
            push(true)
        }
    }

    // ------------------------------------------------------------------ touch (bump) matching

    fun onLocalBump() {
        myBumpAt = now()
        emit("bump")
        if (!readyOn || session != null || pendingEp != null || phase != "idle") return
        restartAdvertising()
        tryMatch()
        val at = myBumpAt
        // phones may only show up a moment after the touch: look again while the window is open
        main.postDelayed({ if (myBumpAt == at) tryMatch() }, 1200)
        main.postDelayed({ if (myBumpAt == at) tryMatch() }, 3000)
        main.postDelayed({
            if (myBumpAt == at && session == null && pendingEp == null && phase == "idle") {
                emit("bump_none")
                restartAdvertising()
            }
        }, BUMP_WINDOW + 500)
    }

    private fun tryMatch() {
        if (session != null || pendingEp != null || phase != "idle") return
        val t = now()
        if (myBumpAt == 0L || t - myBumpAt > BUMP_WINDOW) return
        var best: Peer? = null
        for (p in peers.values) {
            if (p.flag == '0') continue
            if (abs(p.foundAt - myBumpAt) > BUMP_WINDOW) continue
            val b = best
            if (b == null || abs(p.foundAt - myBumpAt) < abs(b.foundAt - myBumpAt)) best = p
        }
        if (best == null && selection.isNotEmpty()) {
            // no touch signal from another phone yet: when exactly one phone is in range it can only be that one
            val byDev = LinkedHashMap<String, Peer>()
            for (p in peers.values) {
                val o = byDev[p.devId]
                if (o == null || p.foundAt >= o.foundAt) byDev[p.devId] = p
            }
            if (byDev.size == 1) best = byDev.values.first()
        }
        val peer = best ?: return
        if (selection.isEmpty() && peer.flag != '2') {
            myBumpAt = 0L
            toast("Pick files first, then touch the phones")
            return
        }
        if (Store.deviceId < peer.devId) {
            connectTo(peer, true)
        } else {
            // the other phone normally starts the link; if it does not, we do it ourselves
            val at = myBumpAt
            main.postDelayed({
                if (session == null && pendingEp == null && phase == "idle" && myBumpAt == at) connectTo(peer, true)
            }, 2500)
        }
    }

    // ------------------------------------------------------------------ connecting

    fun sendTo(endpointId: String) {
        if (session != null || pendingEp != null || phase != "idle") return
        val peer = peers[endpointId]
        if (peer == null) {
            toast("That phone moved away. Try again.")
            return
        }
        if (selection.isEmpty()) {
            toast("Add some files first")
            return
        }
        connectTo(peer, false)
    }

    private fun dbg(t: String) {
        val n = trail.size + 1
        trail.addLast(n.toString() + "." + t)
        while (trail.size > 12) trail.removeFirst()
    }

    private fun resetTransferState() {
        rows = ArrayList()
        outList = ArrayList()
        pidIndex.clear()
        incoming.clear()
        pendingSuccess.clear()
        recvBytes.clear()
        notifAt = 0L
        total = 0L
        msg = ""
        speed = 0L
        lastSpeedAt = 0L
        lastSpeedBytes = 0L
        startedAt = 0L
        endedAt = 0L
        offerSent = false
        autoAccept = false
        connected = false
        role = "none"
        step = ""
        streamPids.clear()
        awaitAck = false
        bumpReq = false
        retries = 0
        ackToken++
        trail.clear()
    }

    private fun connectTo(peer: Peer, bump: Boolean) {
        if (session != null || pendingEp != null) return
        resetTransferState()
        cancelledEps.remove(peer.endpointId)
        bumpReq = bump
        pendingEp = peer.endpointId
        phase = "link"
        dir = if (selection.isNotEmpty()) "out" else "in"
        peerName = peer.name
        startedAt = now()
        TransferService.start(app, "Linking with " + peer.name)
        push(true)
        emit("link")
        val ep = peer.endpointId
        requestLink(peer)
        main.postDelayed({
            if (pendingEp == ep && !connected) {
                pendingEp = null
                fail("Couldn't connect to " + peer.name + ". Keep both phones close, make sure Bluetooth and Wi-Fi are on, and try again.")
            }
        }, 25000)
    }

    private fun requestLink(peer: Peer) {
        val ep = peer.endpointId
        step = "Connecting to " + peer.name + "\u2026"
        push(true)
        val myName = Store.deviceId + "|" + (if (bumpReq) 'B' else 'M') + "|" + clean(Store.deviceName)
        client.requestConnection(myName, ep, lifecycle)
            .addOnFailureListener { e ->
                val code = (e as? ApiException)?.statusCode ?: -1
                if (code != ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT && pendingEp == ep && session == null) {
                    retryOrFail(peer, "Couldn't reach " + peer.name + " (code " + code + "). Keep the phones close and try again.")
                }
            }
    }

    private fun retryOrFail(peer: Peer, why: String) {
        if (retries < 2 && phase == "link") {
            retries++
            step = "Retrying\u2026 (" + (retries + 1) + "/3)"
            push(true)
            val ep = peer.endpointId
            main.postDelayed({
                if (pendingEp == ep && session == null && phase == "link") requestLink(peer)
            }, 900)
        } else {
            pendingEp = null
            fail(why)
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val parts = info.endpointName.split("|", limit = 3)
            val devId = if (parts.isNotEmpty()) parts[0] else endpointId
            val mode = if (parts.size > 1) parts[1] else "M"
            val name = if (parts.size > 2) parts[2] else "Nearby phone"
            val requestedByMe = pendingEp == endpointId
            if (isCancelled(endpointId) || session != null || (pendingEp != null && !requestedByMe) ||
                (phase != "idle" && !requestedByMe)
            ) {
                try {
                    client.rejectConnection(endpointId)
                } catch (_: Exception) {
                }
                return
            }
            val t = now()
            val bumpOk = if (requestedByMe) bumpReq else (mode == "B" && myBumpAt > 0 && t - myBumpAt < BUMP_WINDOW + 3000)
            val shownName = if (requestedByMe && peerName.isNotEmpty()) peerName else name
            session = Session(endpointId, shownName, devId, requestedByMe, bumpOk)
            if (!requestedByMe) {
                resetTransferState()
                peerName = name
                phase = "link"
                dir = "in"
                startedAt = t
                TransferService.start(app, "Linking with $name")
                emit("link")
            }
            autoAccept = bumpOk
            step = "Securing the link\u2026"
            // free the radios for the fast Wi-Fi link
            try {
                client.stopDiscovery()
                client.stopAdvertising()
            } catch (_: Exception) {
            }
            peers.clear()
            push(true)
            client.acceptConnection(endpointId, payloadCb)
                .addOnFailureListener { fail("Connection failed") }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val s = session
            if (s == null || s.endpointId != endpointId) return
            if (result.status.isSuccess) {
                onConnected()
            } else {
                val code = result.status.statusCode
                session = null
                pendingEp = null
                fail("Couldn't connect (code $code). Try again.")
            }
        }

        override fun onDisconnected(endpointId: String) {
            val s = session ?: return
            if (s.endpointId != endpointId) return
            session = null
            pendingEp = null
            // every byte already arrived and we are only writing it to Downloads: let that finish
            var allIn = dir == "in" && rows.isNotEmpty()
            for (r in rows) if (r.done < r.size) allIn = false
            if (allIn && phase == "xfer") return
            if (phase == "link" || phase == "offer" || phase == "xfer") {
                fail("The other phone disconnected")
            }
        }
    }

    private fun onConnected() {
        val s = session ?: return
        connected = true
        pendingEp = null
        dbg(if (s.initiator) "connected as caller" else "connected as answerer")
        step = if (selection.isNotEmpty() && s.initiator) "Preparing your files\u2026" else "Waiting for " + s.peerName + "\u2026"
        push(true)
        if (s.initiator) {
            if (selection.isNotEmpty()) {
                beginOffer()
            } else {
                askPeer()
            }
        }
        val ep = s.endpointId
        main.postDelayed({
            val cur = session
            if (cur != null && cur.endpointId == ep && phase == "link" && rows.isEmpty() && role == "none") {
                fail("The other phone didn't share anything. Pick files on one phone and touch again.")
            }
        }, 25000)
    }

    /** "Do you have anything for me?" - sent when the caller has nothing selected. */
    private fun askPeer() {
        val s = session ?: return
        dbg("ask peer")
        sendJson(s.endpointId, JSONObject().put("t", "ask"))
    }

    private fun onAsk() {
        val s = session ?: return
        dbg("peer asked for files")
        if (phase != "link" || offerSent || role != "none") return
        if (selection.isEmpty()) {
            sendJson(s.endpointId, JSONObject().put("t", "none"))
        } else {
            beginOffer()
        }
    }

    // ------------------------------------------------------------------ sending

    private fun beginOffer() {
        val s = session ?: return
        if (role == "receiver" || offerSent) return
        role = "sender"
        dbg("sending offer")
        dir = "out"
        outList = ArrayList(selection.values)
        rows = ArrayList()
        for (f in outList) rows.add(FileRow(f.name, f.size, f.mime))
        total = 0L
        for (f in outList) total += f.size
        phase = "link"
        push(true)
        val list = ArrayList(outList)
        io.execute {
            val prepared = ArrayList<OutFile>()
            var ok = true
            for (f in list) {
                if (f.splits.isNotEmpty()) {
                    val z = zipSplits(f)
                    if (z == null) {
                        ok = false
                        break
                    }
                    prepared.add(z)
                } else {
                    prepared.add(f)
                }
            }
            main.post {
                val cur = session
                if (cur == null || cur.endpointId != s.endpointId || dir != "out") return@post
                if (!ok) {
                    fail("Couldn't prepare an app for sending")
                    return@post
                }
                outList = prepared
                rows = ArrayList()
                for (f in prepared) rows.add(FileRow(f.name, f.size, f.mime))
                total = 0L
                for (f in prepared) total += f.size
                sendOffer()
            }
        }
    }

    private fun zipSplits(f: OutFile): OutFile? {
        return try {
            val d = File(app.cacheDir, "apks")
            d.mkdirs()
            val z = File(d, f.name)
            ZipOutputStream(BufferedOutputStream(FileOutputStream(z))).use { zo ->
                zo.setLevel(0)
                val all = ArrayList<String>()
                all.add(f.path!!)
                all.addAll(f.splits)
                for (p in all) {
                    val file = File(p)
                    zo.putNextEntry(ZipEntry(file.name))
                    FileInputStream(file).use { it.copyTo(zo, 256 * 1024) }
                    zo.closeEntry()
                }
            }
            OutFile(f.key, f.name, z.length(), f.mime, null, z.absolutePath, f.kind)
        } catch (_: Exception) {
            null
        }
    }

    private fun sendJson(ep: String, o: JSONObject) {
        client.sendPayload(ep, Payload.fromBytes(o.toString().toByteArray(Charsets.UTF_8)))
            .addOnFailureListener { fail("Couldn't talk to the other phone") }
    }

    private fun sendOffer() {
        val s = session ?: return
        if (role != "sender") return
        val o = JSONObject()
        o.put("t", "offer")
        o.put("name", Store.deviceName)
        o.put("total", total)
        val arr = JSONArray()
        for (r in rows) {
            val fo = JSONObject()
            fo.put("n", r.name)
            fo.put("s", r.size)
            fo.put("m", r.mime)
            arr.put(fo)
        }
        o.put("files", arr)
        offerSent = true
        step = "Waiting for " + peerName + " to accept\u2026"
        push(true)
        sendJson(s.endpointId, o)
    }

    private fun onAccepted() {
        if (role != "sender" || !offerSent || phase == "xfer") return
        dbg("peer accepted")
        dir = "out"
        phase = "xfer"
        startedAt = now()
        TransferService.start(app, "Sending to $peerName")
        push(true)
        emit("xfer")
        sendNext(0)
    }

    private fun sendNext(i: Int) {
        val s = session ?: return
        if (role != "sender") return
        if (i >= outList.size) {
            finishSend()
            return
        }
        val f = outList[i]
        try {
            val u = f.uri
            val input: InputStream = if (u != null) {
                app.contentResolver.openInputStream(u) ?: throw IllegalStateException("no stream")
            } else {
                FileInputStream(File(f.path!!))
            }
            val payload = Payload.fromStream(input)
            rows[i].pid = payload.id
            pidIndex[payload.id] = i
            val meta = JSONObject()
            meta.put("t", "file")
            meta.put("pid", payload.id)
            meta.put("i", i)
            meta.put("n", f.name)
            meta.put("s", f.size)
            meta.put("m", f.mime)
            sendJson(s.endpointId, meta)
            client.sendPayload(s.endpointId, payload)
                .addOnFailureListener { fail("Couldn't send " + f.name) }
            emit("file_start", i)
            push(true)
        } catch (e: Exception) {
            fail("Couldn't open " + f.name)
        }
    }

    /**
     * Every byte has left this phone. That is NOT the same as "delivered": the result screen only
     * appears once the other phone says it really saved the files (or it reports a failure).
     */
    private fun finishSend() {
        val s = session ?: return
        awaitAck = true
        push(true)
        val ep = s.endpointId
        val tok = ++ackToken
        main.postDelayed({
            val cur = session
            if (awaitAck && ackToken == tok && cur != null && cur.endpointId == ep) {
                awaitAck = false
                fail("The other phone didn't confirm that it saved the files. Check Downloads/Fling on that phone.")
            }
        }, 90000)
    }

    private fun tellFail(m: String) {
        val s = session ?: return
        try {
            client.sendPayload(s.endpointId, Payload.fromBytes(JSONObject().put("t", "fail").put("m", m).toString().toByteArray(Charsets.UTF_8)))
        } catch (_: Exception) {
        }
    }

    private fun closeEndpoint(ep: String) {
        val cur = session
        if (cur != null && cur.endpointId == ep) {
            session = null
            try {
                client.disconnectFromEndpoint(ep)
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ receiving

    private fun freeBytes(): Long {
        return try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            st.availableBytes
        } catch (_: Exception) {
            Long.MAX_VALUE
        }
    }

    private fun onOffer(o: JSONObject) {
        val s = session ?: return
        if (role == "receiver" && (phase == "xfer" || phase == "offer")) {
            sendJson(s.endpointId, JSONObject().put("t", "reject").put("r", "busy"))
            return
        }
        if (offerSent) {
            if (s.initiator && role == "sender") {
                sendJson(s.endpointId, JSONObject().put("t", "reject").put("r", "busy"))
                return
            }
            offerSent = false   // their offer wins; our files stay selected for next time
        }
        dbg("offer received: " + (o.optJSONArray("files")?.length() ?: 0) + " file(s)")
        dir = "in"
        peerName = o.optString("name", s.peerName)
        val newRows = ArrayList<FileRow>()
        val arr = o.optJSONArray("files") ?: return
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            newRows.add(
                FileRow(
                    Media.safeName(f.optString("n", "file")),
                    f.optLong("s", 0L),
                    f.optString("m", "application/octet-stream")
                )
            )
        }
        if (newRows.isEmpty()) return
        rows = newRows
        pidIndex.clear()
        pendingSuccess.clear()
        total = 0L
        for (r in rows) total += r.size
        if (total > freeBytes()) {
            sendJson(s.endpointId, JSONObject().put("t", "reject").put("r", "space"))
            fail("Not enough storage space for these files")
            return
        }
        if (autoAccept) {
            acceptOffer()
        } else {
            phase = "offer"
            push(true)
            emit("offer")
        }
    }

    fun respond(accept: Boolean) {
        val s = session ?: return
        if (phase != "offer") return
        if (accept) {
            acceptOffer()
        } else {
            sendJson(s.endpointId, JSONObject().put("t", "reject").put("r", "declined"))
            val ep = s.endpointId
            main.postDelayed({ closeEndpoint(ep) }, 700)
            resetToIdle(false)
        }
    }

    private fun acceptOffer() {
        val s = session ?: return
        role = "receiver"
        offerSent = false
        dbg("accepting offer")
        dir = "in"
        phase = "xfer"
        startedAt = now()
        TransferService.start(app, "Receiving from $peerName")
        push(true)
        emit("xfer")
        lastProgressAt = now()
        watchStall(ackToken)
        sendJson(s.endpointId, JSONObject().put("t", "accept"))
    }

    private fun onFileMeta(o: JSONObject) {
        val pid = o.optLong("pid", -1L)
        val i = o.optInt("i", -1)
        if (pid < 0 || i < 0 || i >= rows.size) return
        pidIndex[pid] = i
        rows[i].pid = pid
        val seen = recvBytes[pid]
        if (seen != null && !rows[i].finished) rows[i].done = seen
        emit("file_start", i)
        push()
        dbg("meta " + (i + 1))
        if (incoming[pid]?.type == Payload.Type.STREAM) {
            maybeStartStream(pid)
        } else if (pendingSuccess.remove(pid)) {
            takeIncoming(i, pid)
        }
    }

    /** Starts copying a streamed file as soon as both its bytes and its description are here. */
    private fun maybeStartStream(pid: Long) {
        val idx = pidIndex[pid] ?: return
        val payload = incoming[pid] ?: return
        if (payload.type != Payload.Type.STREAM || idx >= rows.size) return
        if (!streamPids.add(pid)) return
        val row = rows[idx]
        val input: InputStream? = try {
            payload.asStream()?.asInputStream()
        } catch (_: Throwable) {
            null
        }
        if (input == null) {
            val m = "Couldn't open the incoming data for " + row.name + ". Try again."
            tellFail(m)
            fail(m)
            return
        }
        dbg("stream open " + (idx + 1))
        lastProgressAt = now()
        Thread { copyStream(idx, row, input) }.start()
    }

    /** Runs on its own thread: writes the incoming bytes straight into Downloads/Fling. */
    private fun copyStream(idx: Int, row: FileRow, input: InputStream) {
        val cr = app.contentResolver
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, row.name)
        values.put(MediaStore.MediaColumns.MIME_TYPE, row.mime)
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fling")
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)
        var created: Uri? = null
        var wrote = 0L
        var ok = false
        var err = ""
        try {
            val dest = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("can't create file")
            created = dest
            val out = cr.openOutputStream(dest) ?: throw IllegalStateException("can't write file")
            val buf = ByteArray(256 * 1024)
            var lastUi = 0L
            out.use { o ->
                input.use { i ->
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        wrote += n
                        row.done = wrote
                        val t = SystemClock.elapsedRealtime()
                        lastProgressAt = t
                        if (t - lastUi > 120) {
                            lastUi = t
                            main.post {
                                updateSpeed()
                                push()
                            }
                        }
                    }
                }
            }
            ok = wrote >= row.size
            if (ok) {
                val fin = ContentValues()
                fin.put(MediaStore.MediaColumns.IS_PENDING, 0)
                cr.update(dest, fin, null, null)
            }
        } catch (e: Throwable) {
            err = e.message ?: ""
        }
        if (!ok) {
            try {
                created?.let { cr.delete(it, null, null) }
            } catch (_: Throwable) {
            }
        }
        val result: Uri? = if (ok) created else null
        main.post { onStreamSaved(idx, row, result, wrote, err) }
    }

    private fun onStreamSaved(idx: Int, row: FileRow, dest: Uri?, wrote: Long, err: String) {
        if (phase != "xfer" || idx >= rows.size) return
        if (dest == null) {
            val m = "Only " + wrote + " of " + row.size + " bytes of " + row.name + " arrived" +
                (if (err.isNotEmpty()) " ($err)" else "") + ". Keep the phones close and try again."
            tellFail(m)
            fail(m)
            return
        }
        row.done = row.size
        row.saving = false
        row.finished = true
        row.uri = dest.toString()
        Store.addHistory(row.name, row.size, row.mime, "in", peerName, dest.toString())
        emit("file_done", idx)
        push(true)
        var all = true
        for (r in rows) if (!r.finished) all = false
        val s = session
        if (all) {
            if (s != null) sendJson(s.endpointId, JSONObject().put("t", "done"))
            complete()
            if (s != null) {
                val ep = s.endpointId
                main.postDelayed({ closeEndpoint(ep) }, 4000)
            }
        }
    }

    /** If no bytes show up for 30 s the receiver says so instead of sitting at 0% forever. */
    private fun watchStall(tok: Int) {
        main.postDelayed({
            if (tok == ackToken && phase == "xfer" && role == "receiver") {
                if (now() - lastProgressAt > 30000L) {
                    val m = "No data is arriving from " + peerName + ". Keep both phones close, Bluetooth and Wi-Fi on, and try again."
                    tellFail(m)
                    fail(m)
                } else {
                    watchStall(tok)
                }
            }
        }, 5000)
    }

    /**
     * A file has fully arrived. Nearby only keeps the received file readable for a moment, so the
     * stream is opened right here on the callback and the bytes are copied on the worker thread.
     */
    private fun takeIncoming(idx: Int, pid: Long) {
        val payload = incoming.remove(pid)
        if (payload == null) {
            pendingSuccess.add(pid)
            return
        }
        if (idx >= rows.size) return
        val row = rows[idx]
        row.done = row.size
        row.saving = true
        push(true)
        attemptSave(idx, payload, 0)
    }

    private fun attemptSave(idx: Int, payload: Payload, attempt: Int) {
        if (idx >= rows.size) return
        val row = rows[idx]
        val src = openPayload(payload)
        if (src == null) {
            if (attempt < 6 && phase == "xfer") {
                // Nearby can take a moment to finalise the file: try again shortly
                main.postDelayed({ if (phase == "xfer") attemptSave(idx, payload, attempt + 1) }, 350L)
                return
            }
            row.saving = false
            push(true)
            val m = "Couldn't read " + row.name + " from the other phone. Keep Fling open on both phones and try again."
            tellFail(m)
            fail(m)
            return
        }
        io.execute {
            val dest = writeToDownloads(src, row)
            if (dest != null) cleanupPayload(payload)
            main.post {
                row.saving = false
                if (dest == null) {
                    push(true)
                    val m = "Couldn't save " + row.name + ". Free up some space on this phone and try again."
                    tellFail(m)
                    fail(m)
                    return@post
                }
                row.finished = true
                row.uri = dest.toString()
                Store.addHistory(row.name, row.size, row.mime, "in", peerName, dest.toString())
                emit("file_done", idx)
                push(true)
                var all = true
                for (r in rows) if (!r.finished) all = false
                val s = session
                if (all && phase == "xfer") {
                    if (s != null) sendJson(s.endpointId, JSONObject().put("t", "done"))
                    complete()
                    if (s != null) {
                        val ep = s.endpointId
                        main.postDelayed({ closeEndpoint(ep) }, 4000)
                    }
                }
            }
        }
    }

    /** Opens a received file. The Uri Nearby gives us is the documented way in; the rest are backups. */
    private fun openPayload(payload: Payload): InputStream? {
        val f = try {
            payload.asFile()
        } catch (_: Throwable) {
            null
        } ?: return null
        try {
            val u = f.asUri()
            if (u != null) {
                val s = app.contentResolver.openInputStream(u)
                if (s != null) return s
                val fd = app.contentResolver.openFileDescriptor(u, "r")
                if (fd != null) return ParcelFileDescriptor.AutoCloseInputStream(fd)
            }
        } catch (_: Throwable) {
        }
        try {
            val pfd = f.asParcelFileDescriptor()
            try {
                // the descriptor sits at the end of the finished file: go back to the first byte
                Os.lseek(pfd.fileDescriptor, 0L, OsConstants.SEEK_SET)
            } catch (_: Throwable) {
            }
            return ParcelFileDescriptor.AutoCloseInputStream(pfd)
        } catch (_: Throwable) {
        }
        try {
            val jf = f.asJavaFile()
            if (jf != null && jf.exists()) return FileInputStream(jf)
        } catch (_: Throwable) {
        }
        try {
            val guess = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "Nearby/" + payload.id
            )
            if (guess.exists()) return FileInputStream(guess)
        } catch (_: Throwable) {
        }
        return null
    }

    /** Removes Nearby's temporary copy so Downloads doesn't fill up with unnamed leftovers. */
    private fun cleanupPayload(payload: Payload) {
        val f = try {
            payload.asFile()
        } catch (_: Throwable) {
            null
        }
        if (f != null) {
            try {
                val u = f.asUri()
                if (u != null) app.contentResolver.delete(u, null, null)
            } catch (_: Throwable) {
            }
            try {
                f.asJavaFile()?.delete()
            } catch (_: Throwable) {
            }
            try {
                f.close()
            } catch (_: Throwable) {
            }
        }
        try {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "Nearby/" + payload.id
            ).delete()
        } catch (_: Throwable) {
        }
    }

    /** Copies the opened stream into Downloads/Fling and returns the finished MediaStore Uri. */
    private fun writeToDownloads(src: InputStream, row: FileRow): Uri? {
        val cr = app.contentResolver
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, row.name)
        values.put(MediaStore.MediaColumns.MIME_TYPE, row.mime)
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fling")
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)
        var created: Uri? = null
        try {
            val dest = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            created = dest
            var wrote = 0L
            val out = cr.openOutputStream(dest) ?: throw IllegalStateException("no output")
            out.use { o -> src.use { i -> wrote = i.copyTo(o, 256 * 1024) } }
            if (wrote <= 0L || (row.size > 0 && wrote < row.size)) {
                // empty or half a file: never pretend it arrived
                try {
                    cr.delete(dest, null, null)
                } catch (_: Throwable) {
                }
                return null
            }
            val fin = ContentValues()
            fin.put(MediaStore.MediaColumns.IS_PENDING, 0)
            cr.update(dest, fin, null, null)
            return dest
        } catch (e: Throwable) {
            try {
                src.close()
            } catch (_: Throwable) {
            }
            try {
                created?.let { cr.delete(it, null, null) }
            } catch (_: Throwable) {
            }
            return null
        }
    }

    // ------------------------------------------------------------------ payload callbacks

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val b = payload.asBytes() ?: return
                try {
                    handleMsg(JSONObject(String(b, Charsets.UTF_8)))
                } catch (_: Exception) {
                }
            } else if (payload.type == Payload.Type.FILE) {
                incoming[payload.id] = payload
            } else if (payload.type == Payload.Type.STREAM) {
                incoming[payload.id] = payload
                dbg("stream arrived")
                maybeStartStream(payload.id)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            handleUpdate(update)
        }
    }

    private fun handleMsg(o: JSONObject) {
        when (o.optString("t")) {
            "offer" -> onOffer(o)
            "accept" -> onAccepted()
            "file" -> onFileMeta(o)
            "ask" -> onAsk()
            "none" -> {
                if (phase == "link" && rows.isEmpty()) {
                    fail("Nothing to share. Pick files on one phone, then touch again.")
                }
            }
            "reject" -> {
                if (role == "sender" && offerSent) {
                    val r = o.optString("r")
                    fail(
                        when (r) {
                            "space" -> "The other phone doesn't have enough storage"
                            "busy" -> "The other phone is sending right now"
                            else -> "The other phone declined"
                        }
                    )
                }
            }
            "done" -> {
                val s = session
                if (s != null && role == "sender" && awaitAck) {
                    awaitAck = false
                    for (f in outList) {
                        Store.addHistory(f.name, f.size, f.mime, "out", peerName, null)
                        selection.remove(f.key)
                    }
                    complete()
                    val ep = s.endpointId
                    main.postDelayed({ closeEndpoint(ep) }, 800)
                }
            }
            "fail" -> {
                if (role == "sender" && (phase == "xfer" || phase == "link")) {
                    awaitAck = false
                    fail(o.optString("m", "The other phone couldn't save the files"))
                }
            }
        }
    }

    private fun handleUpdate(u: PayloadTransferUpdate) {
        val pid = u.payloadId
        val idx = pidIndex[pid]
        val st = u.status
        if (st == PayloadTransferUpdate.Status.IN_PROGRESS) {
            lastProgressAt = now()
            if (idx != null && idx < rows.size) {
                if (!streamPids.contains(pid)) rows[idx].done = u.bytesTransferred
            } else if (dir == "in") {
                recvBytes[pid] = u.bytesTransferred
            }
            updateSpeed()
            push()
        } else if (st == PayloadTransferUpdate.Status.SUCCESS) {
            if (role == "sender") {
                if (idx != null && idx < rows.size) {
                    rows[idx].done = rows[idx].size
                    rows[idx].finished = true
                    emit("file_done", idx)
                    push(true)
                    sendNext(idx + 1)
                }
            } else if (role == "receiver") {
                if (streamPids.contains(pid)) {
                    // streamed files finish in copyStream
                } else if (idx != null && idx < rows.size) {
                    takeIncoming(idx, pid)
                } else {
                    pendingSuccess.add(pid)
                }
            }
        } else if (st == PayloadTransferUpdate.Status.FAILURE || st == PayloadTransferUpdate.Status.CANCELED) {
            recvBytes.remove(pid)
            val doneAlready = idx != null && idx < rows.size && rows[idx].finished
            if (!doneAlready && (idx != null || incoming.containsKey(pid))) {
                if (phase == "xfer") fail("The transfer was interrupted. Keep the phones close and try again.")
            }
        }
    }

    private fun updateSpeed() {
        val t = now()
        val done = doneBytes()
        if (lastSpeedAt == 0L) {
            lastSpeedAt = t
            lastSpeedBytes = done
            return
        }
        val dt = t - lastSpeedAt
        if (dt >= 500) {
            val inst = (done - lastSpeedBytes) * 1000L / dt
            speed = if (speed == 0L) inst else (speed * 6 + inst * 4) / 10
            lastSpeedAt = t
            lastSpeedBytes = done
        }
    }

    // ------------------------------------------------------------------ finishing

    private fun complete() {
        phase = "done"
        msg = ""
        endedAt = now()
        for (r in rows) {
            r.finished = true
            r.done = r.size
        }
        push(true)
        emit("done")
        TransferService.stop(app)
    }

    private fun cancelAll() {
        for (r in rows) {
            if (r.pid != 0L && !r.finished) {
                try {
                    client.cancelPayload(r.pid)
                } catch (_: Exception) {
                }
            }
        }
        for (k in incoming.keys) {
            try {
                client.cancelPayload(k)
            } catch (_: Exception) {
            }
        }
    }

    private fun fail(m: String) {
        if (phase == "done" || phase == "error") return
        msg = m
        phase = "error"
        endedAt = now()
        for (r in rows) r.saving = false
        val s = session
        session = null
        pendingEp?.let { cancelledEps[it] = now() }
        pendingEp = null
        cancelAll()
        if (s != null) {
            val ep = s.endpointId
            main.postDelayed({
                try {
                    client.disconnectFromEndpoint(ep)
                } catch (_: Exception) {
                }
            }, 600)
        }
        TransferService.stop(app)
        push(true)
        emit("error", -1, m)
    }

    /** User pressed Cancel. */
    fun cancel() {
        if (phase == "idle") return
        val s = session
        session = null
        pendingEp?.let { cancelledEps[it] = now() }
        pendingEp = null
        cancelAll()
        if (s != null) {
            try {
                client.disconnectFromEndpoint(s.endpointId)
            } catch (_: Exception) {
            }
        }
        TransferService.stop(app)
        resetToIdle(true)
    }

    /** User pressed Done on the result screen. */
    fun dismiss() {
        if (phase == "done" || phase == "error") resetToIdle(true)
    }

    private fun resetToIdle(restart: Boolean) {
        val s = session
        session = null
        if (s != null) {
            try {
                client.disconnectFromEndpoint(s.endpointId)
            } catch (_: Exception) {
            }
        }
        phase = "idle"
        resetTransferState()
        myBumpAt = 0L
        push(true)
        if (restart) {
            if (foreground) restartReady() else stopReady()
        } else if (foreground) {
            restartReady()
        }
    }
}

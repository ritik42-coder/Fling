# Fling
Offline phone-to-phone file sharing. Touch the tops of two phones and files fly across (Bluetooth + Wi-Fi Direct, no internet).
Build: upload this zip to a GitHub repo together with the build workflow, then download Fling.apk from Releases.
Needs Android 10+ and Google Play services. Received files go to Downloads/Fling.

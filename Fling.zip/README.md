# Fling
Offline phone-to-phone file sharing. Touch the tops of two phones and files fly across (Bluetooth + Wi-Fi Direct, no internet).
Build: upload this zip to a GitHub repo together with the build workflow, then download Fling.apk from Releases.
Needs Android 10+ and Google Play services. Received files go to Downloads/Fling.

## 1.1.0 changes
- "Sent" now appears only after the other phone confirms the files were really saved; if saving fails, both phones show the error.
- Touch-to-share connects to the phone already in range instead of waiting for a re-advertisement; extra match attempts while the touch window is open.
- Connection retries (3 tries), and a failed/cancelled attempt no longer blocks tapping the same phone again.
- Receiver retries opening the received file a few times before giving up.
- Touch sensor sampled at the fastest rate so a short tap is not missed.
- Permissions requested on first launch; live step text while linking; file-fly animation fires on real file events.

## 1.2.0
- Files now travel as live streams written straight to Downloads/Fling (real byte counts on the receiver).
- Receiver reports "no data arriving" after 30 s instead of sitting at 0%.

## 1.3.0
- Transfer fixed: files now go as real file payloads (the same method AirFlow's offline share uses) instead of live streams, which were stalling at 0%.
- Safe mode: if a file is not moving after 15 s, the receiver switches the link to small chunks automatically, so something always arrives instead of sitting at 0%.
- "Sent" confirmation can no longer be missed when the receiver finishes saving first.
- New animated Send and Receive buttons. Tap Receive on one phone and Send (then pick files) on the other: they link up by themselves and the receiver just taps Accept.
- Photo/video picker rebuilt like the phone gallery: 3-column grid grouped by day, video durations, Select all per day, thumbnails load as you scroll (fixes the stacked/overlapping tiles).
